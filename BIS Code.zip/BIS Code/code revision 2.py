'''

Barrington Advisory Solutions
BIS Development Team Project

'''

service = {
    'Mergers and Acquisitions':3000,
    'Business Valuations':2000,
    'Financial Analysis & Operational Ideas':5000,
    'Strategic Planning Services':3500,
    'Specialized Strategic Consultion Services':4000,
    'Litigation Support':6000
    }

Class QuotaCalc:
    
    ## A class that asks for data about a client and then calculates
    ## both the time required for the service and the total estimate cost

    def __init__(self, cust_name = 'none', co_size = 0, option1, option2, option3)      ##This initializes the class with all of the variables that we will use

        self.name = cust_name
        self.size = co_size
        self.option1 = option1

        if option2 != '':                   ##These if statements are checking to see if the company needs more than one service & if so, then assigns the 'self' value with what they are
            self.option2 = option2
        if option3 != '':
            self.option3 = option3

    def service(self, option1, option2, option3):

        opiton1 = ''

        if option2 != '':
            option_2_cost = service[option2]
        if option3 != '':
            option_3_cost = service[option3]

monthly_service_cost = ##option1 + opiton2 + option3        <- this needs to be fixed to their actual variable names
total_cost = months * monthly_service_cost          ##this calculates the total cost for all of the services 
    

if __name__ == "__main__":
    print('Quota Calculator')
    name = input()
    size = int(input())
    option1 = input()
    option2 = input()
    option3 = input()

    calc = QuotaCalc(name, size, option1, option2, option3)


''' Make groups for the number of employees eg 0 - 20 is small & takes one month.
Then take that one month and multiply it by the number of months
maybe break it into like 5 groups to make it smoother